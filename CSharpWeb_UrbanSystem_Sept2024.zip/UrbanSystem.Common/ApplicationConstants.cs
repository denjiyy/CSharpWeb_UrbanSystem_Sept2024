﻿namespace UrbanSystem.Common
{
    public static class ApplicationConstants
    {
        public const int ReleaseYear = 2024;

        public const string AdminRoleName = "Admin";
    }
}