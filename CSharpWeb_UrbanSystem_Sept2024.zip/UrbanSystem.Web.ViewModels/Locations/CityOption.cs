﻿namespace UrbanSystem.Web.ViewModels.Locations
{
    public class CityOption
	{
		public string Value { get; set; } = null!;
		public string Text { get; set; } = null!;
    }
}
