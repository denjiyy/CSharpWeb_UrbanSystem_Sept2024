﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UrbanSystem.Web.ViewModels.Locations
{
	public class CityOption
	{
		public string Value { get; set; } = null!;
		public string Text { get; set; } = null!;
    }
}
